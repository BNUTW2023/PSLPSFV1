Contents: Two folders. "codePSLPSF" for MATLAB codes, with 13 main files (form Code1 to Code13). "dataPSLPSF" for related data, with 13 related data files (form PSLPSFData1 to PSLPSFData13).

1. System requirements
All codes has been tested on MATLAB 2013a and MATLAB 2023a. Not required non-standard hardware.


2. Installation guide
No compilation required. All codes can run in the operation interface of MATLAB.


3. Instructions for use
Firstly, the "codePSLPSF" folder should be add to path of MATLAB.
1）download the "codePSLPSF" and "dataPSLPSF" folders to computer.
2) start MATLAB
3) click the "Set Path" button in MATLAB,  click "Add with subforders" button, select the folder "codePSLPSF", click save button.

Then, the 13 codes files can be running in MATLAB.Taking “Code1_DemoRespINfig1.m” as an example. 
1) open the file “Code1_DemoRespINfig1.m” in MATLAB. 
2) change the variable "Datapathway" (in line 3) to the path on your computer.
3) click "run" button or use "F9" to run the code. The expected run time for each code file range from 1 to 8 seconds.


4. Detailed description of the code's functionality
1）“Code1_DemoRespINfig1.m”  will show Laminar response patterns of MUA for seven SFs from two individual probe placements. Related to Fig 1e.
2）“Code2_fig1.m”  will show results of diverse laminar patterns. Related to Fig 1f-i.
3）“Code3_fig2.m”  will show results of population-averaged laminar pattern for different SFs. Related to Fig 2.
4）“Code4_cutoffSFLayerINfig3.m”  will show results of Laminar distributions of cutoff SFs for the two column types. Related to Fig 3c-3e.
5）“Code5_cutoffSFcorrelationINfig3.m”  will show figures for relationship between the output/input activation and relative cutoff SF. Related to Fig 3g.
6）“Code6_fig4.m”  will show figures for population-averaged laminar pattern evoked by small stimuli with different SFs. Related to Fig 4.
7）“Code7_GCpatterns.m”  will show figures for population-averaged GC pattern. Related to Fig 5b-5c.
8）“Code8_GCsummary.m”  will show figures for detail results of GC analyse. Related to Fig 5d-5e.
9）“Code9_ModePerformance.m”  will show two figures. One figure for an example of model fitting results for individual probe placements and goodness of fit. Related to Fig 6b-6c. The other figure for population-averaged laminar patterns of three components of the FF & Rec model. Related to Fig 6d.
10）“Code10_ContributionForRespPattern.m”  will show the contribution of the feedforward mechanisms and recurrent mechanism. Related to Fig 6h-6i.
11）“Code11_KmeansINfig1.m”  will show results of k-means clustering. Related to Supplemental Fig. 2.
12）“Code12_correlationAnalysis.m”  will show results of correlation analysis. Related to Fig.5, Fig.6 and Supplemental Fig. 7.
13）“Code13_eccentricityAnalysis”  will show results related to Supplemental Fig. 6.

Codes in “supcodes” provide other supporting functions used for data analysis.






