%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData10.mat'];
load(Datapathway);

%% Contribution of Three mechanisms
SFuse = [0.625,1.25,2,4,6,8,10];PlotColor = [0.5 0.5 0.5;0 0 0;];
figure(12);set(12,'position',[50 50 1200 600]);
subplot(2,5,1);
plot(SFuse,data.MeanSiteMMsfuse(:),'.-','linewidth',1,'Markersize',7,'color',[0 0 1]);hold on;
errorbar(SFuse,data.MeanSiteMMsfuse(:),data.StdSiteMMsfuse(:),'.','linewidth',1,'color',[0 0 1]);
plot(SFuse,data.MeanSitePPsfuse(:),'.-','linewidth',1,'Markersize',7,'color',[1 0 0]);hold on;
errorbar(SFuse,data.MeanSitePPsfuse(:),data.StdSitePPsfuse(:),'.','linewidth',1,'color',[1 0 0]);
box off;set(gca,'TickDir','Out');axis([0 10.5 0 0.8]);axis square;set(gca,'xtick',[0:2:10]);
xlabel('SF (cycles/deg)');ylabel('Relative weight');
plot(SFuse,data.MeanSiteRRsfuse(:),'k.-','linewidth',1,'Markersize',7,'color',[0 0 0]);hold on;
errorbar(SFuse,data.MeanSiteRRsfuse(:),data.StdSiteRRsfuse(:),'.','linewidth',1,'color',[0 0 0]);

subplot(2,5,2);
plot(SFuse,data.MeanSiteMMPPsfuse(:),'k.-','linewidth',1,'Markersize',7,'color',[1 0 1]);hold on;
errorbar(SFuse,data.MeanSiteMMPPsfuse(:),data.StdSiteMMPPsfuse(:),'.','linewidth',1,'color',[1 0 1]);
plotMPss = data.MeanSiteRRsfuse(:);
plotMPss = 2*(plotMPss - 0.15);
plotMPsstd = data.StdSiteRRsfuse(:);
plotMPsstd = (sqrt(2)*(plotMPsstd));
plot(SFuse,plotMPss(:),'k.-','linewidth',1,'Markersize',7,'color',[0 0 0]);hold on;
errorbar(SFuse,plotMPss(:),plotMPsstd(:),'.','linewidth',1,'color',[0 0 0]);
box off;set(gca,'TickDir','Out');axis([0 10.5 -0.3 0.7]);axis square;set(gca,'xtick',[0:2:10]);
xlabel('SF (cycles/deg)');ylabel('MP index');
plot(SFuse,SFuse*0,'k--','linewidth',1);
set(gca,'ytick',[[-0.3:0.3:0.6]]);

subplot(2,5,3);
currPos = find(isnan(data.SiteMMPP)~=1);
    plot(data.SiteMMPP(currPos),data.SiteRR(currPos),'o','Markersize',3,...
        'color',[0.2 0.2 0.2],'markerfacecolor',[0.2 0.2 0.2]);hold on;
[hh,pp] = corrcoef((data.SiteMMPP((currPos))),(data.SiteRR((currPos))));
pfit = polyfit((data.SiteMMPP((currPos))),(data.SiteRR((currPos))),1);
fitxxx = -1:0.001:1;fityyy = (pfit(1).*fitxxx + pfit(2));
plot(fitxxx,fityyy,'color',[0.3 0.3 0.3],'linewidth',2);
box off;set(gca,'TickDir','Out');set(gca,'xtick',[-1:1:1]);axis square;
axis([-1 1 0 1]);text(0.1,1.2,['n = ',num2str(length(currPos))]);
text(-0.8,1.2,['r = ',num2str(round(hh(1,2)*100)/100)]);
text(-0.8,1,['p = ',num2str(round(1000*pp(1,2))/1000)]);ylabel('Contribution of Recurrent');xlabel('MP index');

subplot(2,5,6);Ln = 6;
for CC = 1:2
    plot(1:Ln,squeeze(data.meanContri(CC,:,1)),'.-','linewidth',2,'Markersize',4.5,'color',PlotColor(CC,:));hold on;
    errorbar(1:Ln,squeeze(data.meanContri(CC,:,1)),squeeze(data.stdContri(CC,:,1)),'-','linewidth',2,'color',PlotColor(CC,:));
end
axis xy;view(90,90);plot([1 6],[0 0],'k--');
box off;set(gca,'TickDir','Out');axis([0.5 6.5 0. 1]);
set(gca,'xtick',[1:Ln]);
set(gca,'ytick',[0:0.5:1]);
ylabel('Contribution M','fontsize',13);
set(gca,'xticklabel',{'L2/3','L4B','L4Ca','L4Cb','L5','L6'});

subplot(2,5,7);
for CC = 1:2
    plot(1:Ln,squeeze(data.meanContri(CC,:,2)),'.-','linewidth',2,'Markersize',4.5,'color',PlotColor(CC,:));hold on;
    errorbar(1:Ln,squeeze(data.meanContri(CC,:,2)),squeeze(data.stdContri(CC,:,2)),'-','linewidth',2,'color',PlotColor(CC,:));
end
axis xy;view(90,90);plot([1 6],[0 0],'k--');
box off;set(gca,'TickDir','Out');axis([0.5 6.5 0. 1]);
set(gca,'xtick',[1:Ln]);
set(gca,'ytick',[0:0.5:1]);
ylabel('Contribution P','fontsize',13);
set(gca,'xticklabel',{'L2/3','L4B','L4Ca','L4Cb','L5','L6'});

subplot(2,5,8);
for CC = 1:2
    plot(1:Ln,squeeze(data.meanContri(CC,:,3)),'.-','linewidth',2,'Markersize',4.5,'color',PlotColor(CC,:));hold on;
    errorbar(1:Ln,squeeze(data.meanContri(CC,:,3)),squeeze(data.stdContri(CC,:,3)),'-','linewidth',2,'color',PlotColor(CC,:));
end
axis xy;view(90,90);plot([1 6],[0 0],'k--');
box off;set(gca,'TickDir','Out');
set(gca,'xtick',[1:Ln]);ylabel('Contribution rec','fontsize',13);
set(gca,'xticklabel',{'L2/3','L4B','L4Ca','L4Cb','L5','L6'});
axis([0.5 6.5 0 0.4]);

subplot(2,5,9);
for CC = 1:2
    plot(SFuse,data.MeanRRsf(:,CC),'.-','linewidth',1,'Markersize',7,'color',PlotColor(CC,:));hold on;
    errorbar(SFuse,data.MeanRRsf(:,CC),data.StdRRsf(:,CC),'.','linewidth',1,'color',PlotColor(CC,:));
end
box off;set(gca,'TickDir','Out');axis([0 10.5 0 0.6]);axis square;set(gca,'xtick',[0:2:10]);
xlabel('SF (cycles/deg)');ylabel('Relative weight');title('Recurrent');

subplot(2,5,10);
for CC = 1:2
    currID = data.UseSiteID{CC};
    currPos = currID(isnan(data.SiteMMPP(currID))~=1);
    semilogy(data.SiteRechighSF(currPos),data.SitecutoffSF(currPos),'o','Markersize',3,...
        'color',PlotColor(CC,:),'markerfacecolor',PlotColor(CC,:));hold on;
end
currPos = find(isnan(data.SiteRechighSF)~=1);
[hh,pp] = corrcoef((data.SiteRechighSF((currPos))),log10(data.SitecutoffSF((currPos))));
pfit = polyfit((data.SiteRechighSF((currPos))),log10(data.SitecutoffSF((currPos))),1);
fitxxx = 0:0.001:1;fityyy = 10.^(pfit(1).*fitxxx + pfit(2));
semilogy(fitxxx,fityyy,'color',[0.3 0.3 0.3],'linewidth',2);
box off;set(gca,'TickDir','Out');set(gca,'xtick',[0:0.5:1]);axis square;
axis([0 1 2 20]);text(0.1,30,['n = ',num2str(length(currPos))]);
text(0.5,30,['r = ',num2str(hh(1,2))]);
text(0.5,20,['p = ',num2str(round(100*pp(1,2))/100)]);ylabel('cutoffSF');xlabel('Recurrent HighSF');

