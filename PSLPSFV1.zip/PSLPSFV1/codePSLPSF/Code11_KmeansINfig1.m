%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData11.mat'];
load(Datapathway);

%% k-means clustering
repN = 1000;ColumnN = 2;
[Indxss,Centers,sumd,distance] = kmeans(data.MatrixForCluster,ColumnN,'replicates',repN);

%% show results
PlotdemoIDs = [19,31];
[coeff,score,latent] =pca(data.MatrixForCluster);
plotLabel = {'o','^','s'}; Anisss{1}=1;Anisss{2}=[2,3];Anisss{3}=4; %%%% for three animals
if Indxss(PlotdemoIDs(1))==2
    PlotColor = [0 0 0;0.5 0.5 0.5;];
else
    PlotColor = [0.5 0.5 0.5;0 0 0;];
end

figure(2);subplot(2,2,[1])
for ii = 1:2
    curr1 = find(Indxss==ii & ismember(data.AnimalID',Anisss{1}));
    plot(score(curr1,1),score(curr1,2),'o','color',PlotColor(ii,:),'linewidth',2);hold on;
    curr1 = find(Indxss==ii & ismember(data.AnimalID',Anisss{2}));
    plot(score(curr1,1),score(curr1,2),'^','color',PlotColor(ii,:),'linewidth',2);
    curr1 = find(Indxss==ii & ismember(data.AnimalID',Anisss{3}));
    plot(score(curr1,1),score(curr1,2),'s','color',PlotColor(ii,:),'linewidth',2);
end
for uu = 1:length(PlotdemoIDs)
    curr111 = PlotdemoIDs(uu);currColor = Indxss(curr111);
    plot(score(curr111,1),score(curr111,2),'^','color',PlotColor(currColor,:),'markerfacecolor',PlotColor(currColor,:),'linewidth',2);
end
xlabel('PC1','fontsize',14);
ylabel('PC2','fontsize',14);
box off;axis square;
title(['Group 1  n = ',num2str(length(find(Indxss==1))),'    ','Group 2  n = ',num2str(length(find(Indxss==2)))],'fontsize',12);
axis([-1 1 -1 1]);set(gca,'TickDir','Out');box off;set(gca,'TickDir','Out');box off;

subplot(2,2,[2]);SS = 4;InputID = [4:5];OutputID = [1:3];maxrr = 1.2;
for ani = 1:3
    for ii = 1:2
        currID = find(Indxss==ii & ismember(data.AnimalID',Anisss{ani}));
        curr2 = squeeze(mean(data.MatrixForCluster((currID),OutputID),2));
        curr3 = squeeze(mean(data.MatrixForCluster((currID),InputID),2));
        plot(curr3,curr2,plotLabel{ani},'color',PlotColor(ii,:),'markersize',5,'linewidth',2);hold on;
    end
end
for uu = 1:length(PlotdemoIDs)
    curr111 = (PlotdemoIDs(uu));currColor = Indxss(curr111);
    curr2 = squeeze(mean(data.MatrixForCluster(curr111,OutputID),2));
    curr3 = squeeze(mean(data.MatrixForCluster(curr111,InputID),2));
    plot(curr3,curr2,'^','color',PlotColor(currColor,:),'markerfacecolor',PlotColor(currColor,:),'linewidth',2);
end
box off;plot([-0 1.5],[-0 1.5],'k--');
xlabel('Relative response (L4)','fontsize',10);axis square;
ylabel('Relative response (L2/3)','fontsize',10);axis([-0 1.5 -0 1.5]);
set(gca,'xtick',[0:0.5:1]);set(gca,'ytick',[0:0.5:1]);set(gca,'TickDir','Out');box off;

subplot(4,4,[16]);
for ii = 1:2
    currID = find(Indxss==ii);
    curr2 = squeeze(mean(data.MatrixForCluster(currID,OutputID),2));
    curr3 = squeeze(mean(data.MatrixForCluster(currID,InputID),2));
    curr1 = ((curr2-curr3));
    [aaa,bbb] = hist(curr1,[-1:0.2:1]);
    plot([1:-0.2:-1],(aaa),'color',PlotColor(ii,:),'linewidth',2);hold on;
end
box off;xlabel('Difference','fontsize',10);
ylabel('number','fontsize',12);set(gca,'TickDir','Out');box off;
ylim([0 20]);
