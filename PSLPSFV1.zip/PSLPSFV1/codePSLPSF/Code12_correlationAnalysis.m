%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData12.mat'];
load(Datapathway);

%%
PlotColor = [0.5 0.5 0.5;0 0 0;];SS = 4;SSuse = 3;
figure;
subplot(2,2,4);
for CC = 1:2
    loglog(data.SiteOIindexMean(SS,data.Inids{CC}),data.SiteCutOff(data.Inids{CC}),'o','Markersize',3,...
        'color',PlotColor(CC,:),'markerfacecolor',PlotColor(CC,:));hold on;
end
[hh,pp] = corrcoef(log10(data.SiteOIindexMean(SS,:)),log10(data.SiteCutOff));
pfit = polyfit(log10(data.SiteOIindexMean(SS,:)),log10(data.SiteCutOff),1);
fitxxx = [-2:0.01:1];
fitxxx1 = 10.^fitxxx;fityyy = (pfit(1).*fitxxx + pfit(2));
plot(fitxxx1,10.^fityyy,'color',[0.3 0.3 0.3],'linewidth',2);
box off;set(gca,'TickDir','Out');set(gca,'xtick',[-1:1:1]);axis square;
axis([0.02 20 2.5 14]);
text(0.03,16,['n = ',num2str(size(data.SiteOIindexMean(SS,:),2))]);
text(0.03,14,['r = ',num2str(round(hh(1,2)*100)/100)]);
text(0.8,14,['p = ',num2str(round(1000*pp(1,2))/1000)]);xlabel('Output/Input Activation');ylabel('Cutoff SF');
set(gca,'TickLength',[0.02 0.04]);
set(gca,'xTick',[0.1,1,10]);set(gca,'yTick',[5 10]);
% set(gca,'xTicklabel',{});


CombineOIindex = [data.SiteOIindexMean(:,data.Inids{1}),data.SiteOIindexMean(:,data.Inids{2})];
CombineFlag{1} = 1:length(data.Inids{1});CombineFlag{2} = 31:59;
subplot(2,2,3);
for CC = 1:2
    currPos = CombineFlag{CC}(isnan(data.SiteRechighSF(CombineFlag{CC}))~=1);
    semilogx(CombineOIindex(SS,currPos),data.SiteRechighSF((currPos)),'o','Markersize',3,...
        'color',PlotColor(CC,:),'markerfacecolor',PlotColor(CC,:));hold on;
end
currPos = find(isnan(data.SiteRechighSF)~=1);
[hh,pp] = corrcoef(log10(CombineOIindex(SS,currPos)),(data.SiteRechighSF(currPos)));
pfit = polyfit(log10(CombineOIindex(SS,currPos)),(data.SiteRechighSF(currPos)),1);
fitxxx = [-2:0.01:1];
fitxxx1 = 10.^fitxxx;fityyy = (pfit(1).*fitxxx + pfit(2));
plot(fitxxx1,fityyy,'color',[0.3 0.3 0.3],'linewidth',2);
box off;set(gca,'TickDir','Out');axis square;
% set(gca,'xtick',[-1:1:1]);
axis([0.02 20 0 1]);text(0.7,1.1,['n = ',num2str(length(currPos))]);
text(0.1,1.1,['r = ',num2str(round(hh(1,2)*100)/100)]);
text(0.1,1,['p = ',num2str(round(1000*pp(1,2))/1000)]);xlabel('Output/Input Activation');ylabel('Contritution (rec)');
set(gca,'TickLength',[0.02 0.04]);
set(gca,'xTick',[0.1,1,10]);set(gca,'yTick',[0 0.5 1]);

subplot(2,2,2);
xxxuse = [];yyyuse = [];
for CC = 1:2
    currIDs = data.TwoSiteID{CC,1}';currIDsIn = find(ismember(data.Sitesort(:,1),currIDs)==1)';
    semilogx(data.SiteOIindexmeanSameConditionAsLarge(currIDsIn,1),squeeze(data.SiteConnectRelSF(1,SSuse,currIDs)),'o','Markersize',3,...
        'color',PlotColor(CC,:),'markerfacecolor',PlotColor(CC,:));hold on;
    xxxuse = [xxxuse;data.SiteOIindexmeanSameConditionAsLarge(currIDsIn,1)];
    yyyuse = [yyyuse;squeeze(data.SiteConnectRelSF(1,SSuse,currIDs))];
end
[hh,pp] = corrcoef(log10(xxxuse),yyyuse);
pfit = polyfit(log10(xxxuse),yyyuse,1);
fitxxx = [-2:0.01:1];
fitxxx1 = 10.^fitxxx;fityyy = (pfit(1).*fitxxx + pfit(2));
plot(fitxxx1,fityyy,'color',[0.3 0.3 0.3],'linewidth',2);
box off;set(gca,'TickDir','Out');axis square;
% set(gca,'xtick',[-1:1:1]);
axis([0.02 20 0 0.4]);text(3,0.3,['n = ',num2str(length(data.SmallID))]);
text(0.1,0.4,['r = ',num2str(round(hh(1,2)*100)/100)]);
text(2,0.4,['p = ',num2str(round(1000*pp(1,2))/1000)]);xlabel('Output/Input Activation');ylabel('Connection (rec)');
set(gca,'TickLength',[0.02 0.04]);
set(gca,'xTick',[0.1,1,10]);set(gca,'yTick',[0 0.2 0.4]);


currDatause = data.OIforCmp;
subplot(2,2,1);
xxxuse1 = [];yyyuse1 = [];
for CC = 1:2
    currIDs = data.TwoSiteID{CC,1}';
    currIDsIn = find(ismember(data.Sitesort(:,1),currIDs)==1)';currIn2 = data.SitesortSmall(currIDsIn,2);
    loglog(currDatause(currIDsIn),data.SiteOIindex(currIn2,4),'o','Markersize',3,...
        'color',PlotColor(CC,:),'markerfacecolor',PlotColor(CC,:));hold on;
    xxxuse1 = [xxxuse1;currDatause(currIDsIn)];
    yyyuse1 = [yyyuse1;data.SiteOIindex(currIn2,4)];
end
[hh,pp] = corrcoef(log10(xxxuse1),log10(yyyuse1));
pfit = polyfit(log10(xxxuse1),log10(yyyuse1),1);
fitxxx = [-2:0.01:1];
fitxxx1 = 10.^fitxxx;fityyy = (pfit(1).*fitxxx + pfit(2));
% plot(fitxxx1,10.^fityyy,'color',[0.3 0.3 0.3],'linewidth',2);
box off;set(gca,'TickDir','Out');axis square;
% set(gca,'xtick',[-1:1:1]);
axis([0.02 50 0.02 50]);text(5,50,['n = ',num2str(length(data.SmallID))]);
text(0.05,40,['r = ',num2str(round(hh(1,2)*100)/100)]);
text(5,20,['p = ',num2str(round(1000*pp(1,2))/1000)]);
xlabel('Output/Input Activation');ylabel('Output/Input Activation');
loglog([0.02 50],[1 1],'k--');
loglog([1 1],[0.02 50],'k--');
loglog([0.02 50],[0.02 50],'k--');
set(gca,'TickLength',[0.02 0.04]);
set(gca,'xTick',[0.1,1,10]);set(gca,'yTick',[0.1,1,10]);




