%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData13.mat'];
load(Datapathway);

%%
PlotColor = [0.5 0.5 0.5;0 0 0];ShowLayerName = {'L4Ca','L4Cb','L2/3'};
figure;
for LL = 1:3
    subplot(1,3,LL);currT = data.CutOffSF(:,LL);currT(currT<2.5) = 2.5;
    for CC = 1:2
        semilogy(data.RFeccentricity(data.ConluseID==CC),currT(data.ConluseID==CC),'o','color',PlotColor(CC,:),...
            'markerfacecolor',PlotColor(CC,:),'markersize',3);
        hold on;
    end
    box off;set(gca,'TickDir','Out');axis square;title(ShowLayerName{LL},'fontsize',14);
    set(gca, 'XTick', [0:2:6]);axis([0 6 2.5 12]);
    set(gca, 'YTick', [2.5,5,10]);
    [rrr,ppp] = corrcoef(data.RFeccentricity,log10(data.CutOffSF(:,LL)));
    text(4,14,['r = ',num2str(round(1000*rrr(1,2))/1000)],'fontsize',10);
    if ppp(1,2)>0.001
    text(4,12,['p = ',num2str(round(1000*ppp(1,2))/1000)],'fontsize',10);
    else
        text(4,12,['p < 0.001'],'fontsize',10);
    end
    text(0.5,14,['n = ',num2str(length(currT))],'fontsize',10);
    xlabel('Eccentricity (°)','fontsize',12);ylabel('cutoff SF (cycles/deg)','fontsize',12);
end


%%
%%%%%%%%%% re-plot response pattern using corrected SF
TT = [-50:2:250];SFnum = 4;RelDepth = [0:0.01:1];SFuse = [0.25,0.5,1,2];
figure(13);set(13,'position',[50 100 800 600]);
for CC = 1:2
    for SS = 1:SFnum
        currDyn = squeeze(data.MeanDynSF(:,:,SS,CC));
        NorMean = 1;
        currDynN = currDyn/max(currDyn(:));
        subplot(2,SFnum,SS+(CC-1)*SFnum);
        imagesc(TT,RelDepth,currDynN,[-0.3 1]);hold on;xlim([0 150]);box off;set(gca,'TickDir','Out');
        WT_plotboundry([0 150],'w',15);set(gca, 'YTick', [0 1]);
        text(30,-0.1,['octaves =',num2str(SFuse(SS))],'fontsize',12);colormap jet;
        if SS==1
            ylabel('Relative Depth');text(-100,0.5,['Group ',num2str(CC)]);
            xlabel('Time(ms)');
        end
    end
end




