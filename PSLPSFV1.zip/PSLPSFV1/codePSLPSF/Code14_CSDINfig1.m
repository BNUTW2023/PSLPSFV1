%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData14.mat'];
load(Datapathway);
figure;
for kk = 1:2
    subplot(1,2,kk);
    imagesc(data.Time,data.RelDepth,squeeze(data.CSD(:,:,kk)),[-5 5]);hold on;xlim([0 150]);box off;set(gca,'TickDir','Out');
    WT_plotboundry([0 150],'k',16);set(gca, 'YTick', [0 1]);
    ylabel('Relative depth');xlabel('Time (ms)');colormap jet;
end

posbar = colorbar;set(posbar,'position',[0.95,0.35,0.008,0.2]);
