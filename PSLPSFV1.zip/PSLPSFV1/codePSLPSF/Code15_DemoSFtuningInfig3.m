%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData15.mat'];
load(Datapathway);


FitX = logspace(log10(0.3),log10(20),100);
figure;
for ii = 1:length(data.SF)
    currSF = data.SF{ii};currM1 = data.RawTuning{ii}(1,:);
    currFitSFtun = data.FitTuning{ii}(1,:);
    subplot(1,3,ii);
    plot(currSF,currM1/max(currFitSFtun),'k.','linewidth',2);hold on;
    plot(FitX,currFitSFtun/max(currFitSFtun),'k','linewidth',2);

    currM1 = data.RawTuning{ii}(2,:);
    currFitSFtun = data.FitTuning{ii}(2,:);
    plot(currSF,currM1/max(currFitSFtun),'r.','linewidth',2);
    plot(FitX,currFitSFtun/max(currFitSFtun),'r','linewidth',2);
    box off;set(gca,'TickDir','Out');
    axis square;box off;plot(FitX,FitX*0,'--','color',[0.5 0.5 0.5]);
    plot(FitX,FitX*0+0.5,'--','color',[0.5 0.5 0.5]);
    set(gca,'ytick',[0:0.5:1]);xlabel('SF (cycles/deg)');axis([0 20 -0.15 1.25]);
    ylabel('Normalized response');set(gca,'xscale','log');set(gca,'xtick',[1,10]);
    %         set(gca,'xscale','log');
end







