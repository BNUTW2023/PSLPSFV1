%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData16.mat'];
load(Datapathway);

TT = [-50:2:250];

alllabels{1} = 'Group 1';alllabels{2} = 'Group 2';

figure;
for ii = 1:length(data.Depth)
    for SS = 1:2
        subplot(2,4,(ii-1)*4+1+(SS-1)*2);
        currDyn1 = data.Smallsize{ii,SS};
        currDyn2 = data.Largesize{ii,SS};
        imagesc(TT,data.Depth{ii},currDyn1,[-0.3 1]);
        hold on;colormap jet;
        WT_plotboundry([0,150],'w',15);axis([0,150,0,1]);box off;
        set(gca, 'YTick',[0 1]);set(gca,'TickDir','Out');
        if SS==1
            text(-108,0.1,alllabels{ii});
            xlabel('Time (ms)');ylabel('relative depth');
        end
        
        subplot(2,4,(ii-1)*4+2+(SS-1)*2);
        imagesc(TT,data.Depth{ii},currDyn2,[-0.3 1]);
        hold on;
        WT_plotboundry([0,150],'w',15);axis([0,150,0,1]);box off;
        set(gca, 'YTick',[0 1]);set(gca,'TickDir','Out');
    end
end

