%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData17.mat'];
load(Datapathway);

figure;curM = 100;currmin = 0.01;
subplot(1,2,1);curr1 = data.RespNorcompG1(:,1);
curr2 = data.RespNorcompG1(:,2);
loglog(curr1,curr2,'o','color',[0.5 0.5 0.5],'markersize',3,'markerfacecolor',[0.5 0.5 0.5]);hold on;
curr1 = data.RespNorcompG2(:,1);
curr2 = data.RespNorcompG2(:,2);
loglog(curr1,curr2,'ko','markersize',3,'markerfacecolor',[0. 0. 0.]);
loglog([currmin curM],[currmin curM],'k--');axis([currmin curM currmin curM]);box off;axis square;
[hhh2,ppp2] = corrcoef(log10(data.RespNorcomp(:,1)),log10(data.RespNorcomp(:,2)));
text(0.05,50,['n = ',num2str(size(data.RespNorcomp,1))]);
text(0.05,30,['r = ',num2str(round(hhh2(1,2)*100)/100)]);
text(0.05,10,['p = ',num2str(round(ppp2(1,2)*10000)/10000)]);set(gca,'TickDir','Out');
xlabel('Output/Input  activation');
ylabel('Output/Input  activation');
loglog([1 1],[currmin curM],'k--');
loglog([currmin curM],[1 1],'k--');
