%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData18.mat'];
load(Datapathway);

RandScale = 0.1;
figure;
subplot(2,1,1);
bar([1,2.8],data.Firingrate(1,:),0.4,'Edgecolor',[0.5 0.5 0.5],'Facecolor',[1 1 1],'linewidth',1);hold on;
xxxp1 = RandScale*randn([1 length(data.SubFirAll{1}(:,1))]);
xxxp2 = RandScale*randn([1 length(data.SubFirAll{1}(:,2))]);
for ii = 1:length(data.Firingrate(1,:))
    plot(xxxp1+1,(data.SubFirAll{1}(:,1)),'.','color',[0.5 0.5 0.5]);hold on;
    plot(xxxp2+2.8,(data.SubFirAll{1}(:,2)),'.','color',[0.5 0.5 0.5]);
end
errorbar([1,2.8],data.Firingrate(1,:),data.FiringrateStd(1,:),'.','color',[1 0. 0.],'linewidth',1);

bar([5.2,7],data.Firingrate(2,:),0.4,'Edgecolor',[0. 0. 0.],'Facecolor',[1 1 1],'linewidth',1);hold on;
box off;set(gca,'TickDir','Out');set(gca,'xtick',[1,2.8,5.2,7]);
xxxp1 = RandScale*randn([1 length(data.SubFirAll{2}(:,1))]);
xxxp2 = RandScale*randn([1 length(data.SubFirAll{2}(:,2))]);
for ii = 1:length(data.Firingrate(2,:))
    plot(xxxp1+5.2,data.SubFirAll{2}(:,1),'.','color',[0. 0. 0.]);hold on;
    plot(xxxp2+7,data.SubFirAll{2}(:,2),'.','color',[0. 0. 0.]);
end
errorbar([5.2,7],data.Firingrate(2,:),data.FiringrateStd(2,:),'.','color',[1. 0. 0.],'linewidth',2);
set(gca,'yscale','log');axis([-0.3 8.2 1 100]);


subplot(2,1,2);
bar([1,2.8],data.Cutoff(1,:),0.4,'Edgecolor',[0.5 0.5 0.5],'Facecolor',[1 1 1],'linewidth',1);hold on;
xxxp1 = RandScale*randn([1 length(data.Cutoffcompall{1}(:,1))]);
xxxp2 = RandScale*randn([1 length(data.Cutoffcompall{1}(:,2))]);
for ii = 1:length(data.Cutoff(1,:))
    plot(xxxp1+1,data.Cutoffcompall{1}(:,1),'.','color',[0.5 0.5 0.5]);hold on;
    plot(xxxp2+2.8,data.Cutoffcompall{1}(:,2),'.','color',[0.5 0.5 0.5]);
end
errorbar([1,2.8],data.Cutoff(1,:),data.CutoffStd(1,:),'.','color',[1 0. 0.],'linewidth',2);

bar([5.2,7],data.Cutoff(2,:),0.4,'Edgecolor',[0. 0. 0.],'Facecolor',[1 1 1],'linewidth',1);hold on;
box off;set(gca,'TickDir','Out');set(gca,'xtick',[1,2.8,5.2,7]);
xxxp1 = RandScale*randn([1 length(data.Cutoffcompall{2}(:,1))]);
xxxp2 = RandScale*randn([1 length(data.Cutoffcompall{2}(:,2))]);
for ii = 1:length(data.Cutoff(2,:))
    plot(xxxp1+5.2,data.Cutoffcompall{2}(:,1),'.','color',[0. 0. 0.]);hold on;
    plot(xxxp2+7,data.Cutoffcompall{2}(:,2),'.','color',[0. 0. 0.]);
end
errorbar([5.2,7],data.Cutoff(2,:),data.CutoffStd(2,:),'.','color',[1. 0. 0.],'linewidth',2);
set(gca,'yscale','log');axis([-0.3 8.2 1 30]);





