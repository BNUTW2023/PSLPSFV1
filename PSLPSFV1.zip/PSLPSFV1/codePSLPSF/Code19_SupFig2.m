%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData19.mat'];
load(Datapathway);

UseLnameIn = {'L2','L3','L4B','L4Ca','L4Cb'};SS = 4;
figure(1);set(1,'position',[60 60 1000 400]);
subplot(2,2,1);
currM = data.MUAresp;
imagesc(currM(1:5,:),[-0.3 1]);box off;colormap jet;
set(gca,'ytick',[1:length(UseLnameIn)]);
set(gca,'yticklabel',UseLnameIn);set(gca,'TickDir','Out');box off;

subplot(2,2,3);
currM = data.SNRresp;
imagesc(currM(1:5,:),[-0.3 1]);box off;
set(gca,'ytick',[1:length(UseLnameIn)]);
set(gca,'yticklabel',UseLnameIn);set(gca,'TickDir','Out');box off;


subplot(2,2,2);
currM = data.MUArespSortBySNR;
imagesc(currM(1:5,:),[-0.3 1]);box off;
set(gca,'ytick',[1:length(UseLnameIn)]);
set(gca,'yticklabel',UseLnameIn);set(gca,'TickDir','Out');box off;

subplot(2,2,4);
currM = data.SNRrespSortBySNR;
imagesc(currM(1:5,:),[-0.3 1]);box off;
set(gca,'ytick',[1:length(UseLnameIn)]);
set(gca,'yticklabel',UseLnameIn);set(gca,'TickDir','Out');box off;


