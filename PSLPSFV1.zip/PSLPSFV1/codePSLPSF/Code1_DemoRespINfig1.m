%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData1.mat'];
load(Datapathway);
TT = [-50:2:250];SFnum = 7;
figure(1);set(1,'position',[50,300,1000,400]);
for ii = 1:length(data.RespDyn)
    currIDs = find(data.depthAll(:,ii)>0 & data.depthAll(:,ii)<1);
    for SS = 1:SFnum
        subplot(2,SFnum,(ii-1)*7+SS);
        currDyn = squeeze(data.RespDyn{ii}(:,:,SS));currDynuse = currDyn(currIDs,:);
        currDyn = currDyn/max(currDynuse(:));
        imagesc(TT,data.depthAll(:,ii),currDyn,[-0.3 1]);
        hold on;set(gca,'TickDir','Out');
        WT_plotboundry([0,150],'k',16);axis([0,150,0,1]);box off;
        set(gca, 'YTick',[0 1]);xlabel('Time (ms)');
        if SS==1
            ylabel('Relative Depth');text(-180,0.5,['Demo ',num2str(ii)]);
        end
        text(30,-0.05,['SF = ',num2str(data.SFs{ii}(SS))]);colormap jet;
    end
end
posbar = colorbar;set(posbar,'position',[0.95,0.35,0.008,0.2]);
