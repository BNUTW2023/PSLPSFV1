%% load data
clear all;close all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData20.mat'];
load(Datapathway);
nn = 0;
figure(1);set(1,'position',[200 150 1000 200]);
for Ani = 1:3
    for kk = 1:2
        nn = nn + 1;
        subplot(1,6,nn);
        imagesc(data.Time,data.RelDepth,squeeze(data.CSD(:,:,kk,Ani)),[-5 5]);hold on;xlim([0 150]);box off;set(gca,'TickDir','Out');
        WT_plotboundry([0 150],'k',16);set(gca, 'YTick', [0 1]);
        ylabel('Relative depth');xlabel('Time (ms)');colormap jet;
    end
end
posbar = colorbar;set(posbar,'position',[0.95,0.35,0.008,0.2]);
