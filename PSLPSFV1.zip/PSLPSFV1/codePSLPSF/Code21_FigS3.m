%% load data
clear all;close all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData21.mat'];
load(Datapathway);
AniName{1} = 'DQ';AniName{2} = 'DK';AniName{3} = 'QQ';
TTs = [-50:2:250];RelDepth = [0:0.01:1];SFnum = 7;
SFuse = [0.625,1.25,2,4,6,8,10];

for Ani = 1:length(AniName)
    figure(Ani);set(Ani,'position',[50 100 1000 400]);sgtitle(AniName{Ani},'fontsize',15);
    for CC = 1:2
        for SS = 1:SFnum
            currDynN = data.DynMUA{Ani,CC,SS};
            subplot(2,SFnum,SS+(CC-1)*SFnum);
            imagesc(TTs,RelDepth,currDynN,[-0.3 1]);hold on;xlim([0 150]);box off;set(gca,'TickDir','Out');
            WT_plotboundry([0 150],'w',15);set(gca, 'YTick', [0 1]);
            text(30,-0.1,['SF=',num2str(SFuse(SS))],'fontsize',12);colormap jet;
            if SS==1
                text(-150,0.5,['Group ',num2str(CC)],'fontsize',12);
            end
        end
    end
end




