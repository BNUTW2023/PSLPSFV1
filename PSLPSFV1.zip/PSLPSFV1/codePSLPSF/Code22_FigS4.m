%% load data
clear all;close all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData22.mat'];
load(Datapathway);SFuse = [0.625,1.25,2,4,6,8,10];
PlotColor = [0.5 0.5 0.5;0 0 0];PlotSS = [1,4,7];

figure;LL = 2;
subplot(2,4,1);
for CC = 1:2
    errorbar(SFuse,squeeze(data.MeanSERSFuse(:,CC,LL)),...
        squeeze(data.StdSERSFuse(:,CC,LL)),'color',PlotColor(CC,:));hold on;
end
box off;axis([0 10.5 0 2.5]);ylabel('log SER');xlabel('SF (cycles/deg)');
plot(SFuse,log10(SFuse*0+3),'k--');set(gca,'TickDir','Out');box off;axis square;
title(['L4C'],'fontsize',12);

for SS1 = 1:3
    subplot(2,4,1+SS1);
    SS = (SS1);
    for CC = 1:2
        plot([0.5:0.25:2.5],data.histN{SS,LL}(CC,:),'color',PlotColor(CC,:),'linewidth',2);hold on;
        currmean = data.meanV{SS,LL}(CC);
        plot(currmean,108,'v','color',PlotColor(CC,:),'linewidth',3,'Markersize',3);
%         mean(log10(SEReachSFAll{SS}(dpos)))
    end
    box off;axis([0.5 2.5 0 110]);xlabel('log SER');ylabel('Probability (%)');
    set(gca,'TickDir','Out');box off;axis square;title(['SF = ',num2str(SFuse(PlotSS(SS)))],'fontsize',12);
end

subplot(2,4,5);LL = 1;
for CC = 1:2
    errorbar(SFuse,squeeze(data.MeanSERSFuse(:,CC,LL)),...
        squeeze(data.StdSERSFuse(:,CC,LL)),'color',PlotColor(CC,:));hold on;
end
box off;axis([0 10.5 0 2.5]);ylabel('log SER');xlabel('SF (cycles/deg)');
plot(SFuse,log10(SFuse*0+3),'k--');set(gca,'TickDir','Out');box off;axis square;
title(['L2/3'],'fontsize',12);


for SS1 = 1:3
    subplot(2,4,5+SS1);
    SS = (SS1);
    for CC = 1:2
        plot([0.5:0.25:2.5],data.histN{SS,LL}(CC,:),'color',PlotColor(CC,:),'linewidth',2);hold on;
        currmean = data.meanV{SS,LL}(CC);
        plot(currmean,108,'v','color',PlotColor(CC,:),'linewidth',3,'Markersize',3);
%         mean(log10(SEReachSFAll{SS}(dpos)))
    end
    box off;axis([0.5 2.5 0 110]);xlabel('log SER');ylabel('Probability (%)');
    set(gca,'TickDir','Out');box off;axis square;
end



