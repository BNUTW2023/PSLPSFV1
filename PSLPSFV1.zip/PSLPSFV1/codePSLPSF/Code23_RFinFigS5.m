%% load data
clear all;close all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData23.mat'];
load(Datapathway);

%% RF
RFSNRthre = 2.5;RFthre = 0.8;
maxE = 5;maxE1 = 2.5;
figure;
for ii = 1:10
    subplot(2,5,ii);
    for uu = 1:2
        for kkk = 1:length(data.RFHH{ii,uu})
            plot(data.RFHH{ii,uu}(kkk) + data.RFsigma{ii,uu}(kkk)*cos([0:0.01:1.1]*pi*2)*2.3,data.RFVV{ii,uu}(kkk)+ data.RFsigma{ii,uu}(kkk)*sin([0:0.01:1.1]*pi*2)*2.3,'color',[0.5 0.5 0.5]);
            hold on;plot(data.RFHH{ii,uu}(kkk),data.RFVV{ii,uu}(kkk),'k.');
        end
    end
    plot([-maxE1 maxE1],[0 0],'k');plot([0 0],[-maxE maxE],'k');
    set(gca, 'XTick', [-5:2.5:5],'fontsize',14);set(gca, 'YTick', [-5:2.5:5],'fontsize',14);
    set(gca,'TickDir','Out');axis equal;axis([-maxE1*1.001 maxE1*1.001 -maxE 0.*maxE]);
    if ii == 9
    xlabel('Horizontal (deg)','fontsize',14);ylabel('Vertical (deg)','fontsize',14);
    end
    title(['#',num2str(ii)]);
    plot(0,0,'ro','markerfacecolor','r','markersize',3);
end

