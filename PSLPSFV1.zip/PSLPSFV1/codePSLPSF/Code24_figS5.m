%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData24.mat'];
load(Datapathway);

%% show results
SFuse = [0.625,1.25,2,4,6,8,10];
SFnum = 7;
TT = [-50:2:250];RelDepth = [0:0.01:1];
figure(24);set(24,'position',[50 100 1200 600]);
for CC = 1:2
    for SS = 1:SFnum
        currDynN = squeeze(data.DemoDyn{CC,SS});currDynN = currDynN/max(currDynN(:));
        subplot(3,SFnum,SS+(CC-1)*SFnum);
        imagesc(TT,data.DemoDepth{CC,SS},currDynN,[-0.3 1]);hold on;xlim([0 150]);box off;set(gca,'TickDir','Out');
        WT_plotboundry([0 150],'w',15);set(gca, 'YTick', [0 1]);axis([0 150 0 1]);
        text(30,-0.1,['SF=',num2str(SFuse(SS))],'fontsize',12);colormap jet;
        if SS==1
            ylabel('Relative Depth');text(-150,0.5,['Demo ',num2str(CC)]);
            xlabel('Time(ms)');
        end
    end
end


figure(25);set(25,'position',[50 100 1200 600]);
for CC = 1:2
    for SS = 1:SFnum
        currDynN = squeeze(data.MeanDyn{CC,SS});currDynN = currDynN/max(currDynN(:));
        subplot(3,SFnum,SS+(CC-1)*SFnum);
        imagesc(TT,RelDepth,currDynN,[-0.3 1]);hold on;xlim([0 150]);box off;set(gca,'TickDir','Out');
        WT_plotboundry([0 150],'w',15);set(gca, 'YTick', [0 1]);axis([0 150 0 1]);
        text(30,-0.1,['SF=',num2str(SFuse(SS))],'fontsize',12);colormap jet;
        if SS==1
            ylabel('Relative Depth');text(-150,0.5,['Group ',num2str(CC)]);
            xlabel('Time(ms)');
        end
    end
end

plotL = 2;plotSFID = 1:6;PlotColor = [0.5 0.5 0.5;0 0 0;];
for SS = 1:SFnum
    subplot(3,SFnum,SS+(3-1)*SFnum);
    for CC = 1:2
        currN = squeeze(data.nnnsNorResplog(CC,SS,plotL,:));
        plot(data.binHH,cumsum(currN/sum(currN)*100),'color',PlotColor(CC,:),'linewidth',2);hold on;box off;set(gca,'TickDir','Out');
        hold on;box off;ylabel('Cumulative probability (%)');axis square;
        plot(data.meanRespNorlog(CC,SS,plotL),108,'v','color',PlotColor(CC,:),'linewidth',3,'Markersize',3);
        text(0.1,15*CC,['n = ',num2str((sum(currN)))],'color',PlotColor(CC,:));
        xlabel('Output/Input Activation');
    end
    plot([0 0],[0 100],'k--');
end




