%% load data
clear all;close all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData27.mat'];
load(Datapathway);

figure;
for uu = 1:length(data.SiteHH)
        cu1 = (uu);
        plot(data.SiteHH(cu1) + data.SiteSigma(cu1)*cos([0:0.01:1.1]*pi*2)*2.3,data.SiteVV(cu1)+ data.SiteSigma(cu1)*sin([0:0.01:1.1]*pi*2)*2.3,'c');
        hold on;
        for kk = 1:length(data.SiteInHH{uu})
            plot(data.SiteInHH{uu}((kk)),data.SiteInVV{uu}((kk)),'ko','markersize',1);
        end
end
plot([-3 6.5],[0 0],'k');plot([0 0],[-6.5 3],'k');
set(gca, 'XTick', [-5:2.5:5],'fontsize',14);set(gca, 'YTick', [-5:2.5:5],'fontsize',14);
set(gca,'TickDir','Out');axis equal;axis([-2.5 6 -6.5 2]);
xlabel('Horizontal (deg)','fontsize',14);ylabel('Vertical (deg)','fontsize',14);
plot(0,0,'ro','markerfacecolor','r','markersize',3);



