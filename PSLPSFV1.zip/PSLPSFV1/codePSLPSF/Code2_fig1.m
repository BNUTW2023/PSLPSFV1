%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData2.mat'];
load(Datapathway);

%% k-means clustering
InputID = [4:5];OutputID = [1:3];
PlotdemoIDs = [19,31];
PlotColor = [0 0 0;0.5 0.5 0.5;];

%% show results
figure(15);set(15,'position',[200 200 1000 500]);
subplot(1,3,1);
curr2 = squeeze(mean(data.MatrixForCluster(:,OutputID),2));
curr3 = squeeze(mean(data.MatrixForCluster(:,InputID),2));
curr1 = ((curr2-curr3));
[dip, p_value, xlow, xup, boot_dip]=CalibratedHartigansDipSignifTest(curr1,1000);
[aaa,bbb] = hist((curr1),[-1:0.2:1]);
plot([-1:0.2:1],fliplr(aaa),'color',PlotColor(1,:),'linewidth',2);hold on;
box off;xlabel('Response difference','fontsize',10);
ylabel('number','fontsize',12);set(gca,'TickDir','Out');box off;
ylim([0 20]);axis square;set(gca,'xtick',[-1 0 1]);set(gca,'xticklabel',[1 0 -1]);
text(0.1,18,['p = 0.02']);

%%
%%%%%%%%% 1 for DQ, 2 and 3 for DK, 4 for QQ
Anisss{1} = 1;Anisss{2} = [2,3];Anisss{3} = [4];

%%%%%%%%
plotLbale = {'Low','High'};
for SS1 = 1:2
    curr = data.SiteOIindex(:,SS1);
    subplot(2,3,3*(SS1-1)+2);
    [aaa,bbb] = hist(log10(curr),[-0.9:0.2:0.9]);
    bar(bbb,aaa,0.8,'facecolor',[1 1 1],'edgecolor',[0.2 0.2 0.2]);hold on;plot([0 0],[0 30],'k--');
    axis([-1.05 1.05 0 20]);box off;title([plotLbale{SS1},'  SF ']);set(gca,'TickDir','Out');
    set(gca,'xtick',[-1 0 1]);set(gca,'xticklabel',[0.1 1 10]);
    set(gca,'ytick',[0:10:20]);
end
xlabel('Output/Input activation');ylabel('number');
text(0.5,10,['n = ',num2str(length(find(curr>1)))]);
text(-0.8,10,['n = ',num2str(length(find(curr<=1)))]);

plotLabels = {'o','^','s'};PlotColor = [0.5 0.5 0.5;0 0 0;];
subplot(1,3,[3]);
for CC = 1:length(data.TwoSiteID)
    for Ani = 1:length(Anisss)
        currID = data.TwoSiteID{CC}(ismember(data.AnimalID(data.TwoSiteID{CC}),Anisss{Ani}));
        curr1 = data.SiteOIindex(currID,1);curr1(curr1<0.1) = 0.1;
        curr2 = data.SiteOIindex(currID,2);curr2(curr2<0.1) = 0.1;
        loglog(curr1,curr2,[plotLabels{Ani}],'color',PlotColor(CC,:),'linewidth',1);
        axis square;axis([0.1 10 0.1 10]);hold on;
    end
end

curr1 = data.SiteOIindex(:,1);curr1(curr1<0.1) = 0.1;
curr2 = data.SiteOIindex(:,2);curr2(curr2<0.1) = 0.1;
for dd = 1:2
    currID = (data.PlotdemoIDs(dd));
    loglog(curr1(currID),curr2(currID),[plotLabels{2}],'color',PlotColor(dd,:),'linewidth',1,...
        'markerfacecolor',PlotColor(dd,:));
end
loglog([0.01 10],[0.01 10],'k--');
loglog([0.01 10],[1 1],'k--');
loglog([1 1],[0.01 10],'k--');box off;set(gca,'TickDir','Out');
xlabel('Output/Input activation   Low SF');ylabel('Output/Input activation  High SF');

[pppCC,hhhCC] = signrank(data.SiteOIindex(:,1),data.SiteOIindex(:,2));




