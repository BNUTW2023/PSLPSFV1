%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData3.mat'];
load(Datapathway);

%% hist
SFuse = [0.625,1.25,2,4,6,8,10];
TT = [-50:2:250];SFnum = length(SFuse);RelDepth = [0:0.01:1];
binHH = [-0.9:0.2:0.9];clear nnnsOIact meanOIact;
for CC = 1:2
    for SS = 1:SFnum
        [nnnsOIact(CC,SS,:),bbbs] = hist(log10(data.OIactivation{CC,SS}),binHH);
        meanOIact(CC,SS) = mean(log10(data.OIactivation{CC,SS}));
    end
end

%% show results
figure(3);set(3,'position',[50 100 1200 600]);
for CC = 1:2
    for SS = 1:SFnum
        currDyn = squeeze(data.MeanDynSF(:,:,SS,CC));
        NorMean = 1;
        currDynN = currDyn/max(currDyn(:));
        subplot(3,SFnum,SS+(CC-1)*SFnum);
        imagesc(TT,RelDepth,currDynN,[-0.3 1]);hold on;xlim([0 150]);box off;set(gca,'TickDir','Out');
        WT_plotboundry([0 150],'w',15);set(gca, 'YTick', [0 1]);
        text(30,-0.1,['SF=',num2str(SFuse(SS))],'fontsize',12);colormap jet;
        if SS==1
            ylabel('Relative Depth');text(-200,0.5,['Group ',num2str(CC)]);
            xlabel('Time(ms)');
        end
    end
end

plotL = 1;plotSFID = 1:6;PlotColor = [0.5 0.5 0.5;0 0 0;];
for SS = 1:SFnum
    subplot(3,SFnum,SS+(3-1)*SFnum);
    for CC = 1:2
        currN = squeeze(nnnsOIact(CC,SS,:));
        plot(binHH,cumsum(currN/sum(currN)*100),'color',PlotColor(CC,:),'linewidth',2);hold on;box off;set(gca,'TickDir','Out');
        hold on;box off;ylabel('Cumulative probability (%)');axis square;
        plot(meanOIact(CC,SS),108,'v','color',PlotColor(CC,:),'linewidth',3,'Markersize',3);
        text(0.1,15*CC,['n = ',num2str((sum(currN)))],'color',PlotColor(CC,:));
        xlabel('Output/Input Activation');
    end
    plot([0 0],[0 100],'k--');
end

%% statistic
for SS = 1:SFnum
    [pppOI(SS),hhhOI(SS)] = ranksum(data.OIactivation{1,SS},data.OIactivation{2,SS});
end





