%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData4.mat'];
load(Datapathway);

%% distribution
Lalernamess = {'L2/3','L4B','L4Ca','L4Cb','L5','L6'};

PlotColor = [0.5 0.5 0.5;0 0 0;];
PlotColorSS{1} = [0.5 0.5 0.5;0  0.8  1;1.0000 0.55  0.55;0  0.8 0];
PlotColorSS{2} = [0 0 0; 0 0 1;1 0 0;0 0.4 0;];
Boundryplot1 = [0,0.43,0.55,0.67];
Boundryplot2 = [0.43,0.55,0.67,1];
Boundryplot11 = [0,0.35,0.43,0.55,0.67,0.81];
Boundryplot12 = [0.35,0.43,0.55,0.67,0.81,1];Ani = 4;Marks = 2;

PlotR = [2 16];
plotCC = [1,2];clear nnnscutSFuse;plotWin{1} = [1,6,11]+1;plotWin{2} = [1,6,11]+2;
figure(4);set(4,'position',[100 50 1000 500]);
for ii = 1:length(plotCC)
    subplot(5,5,plotWin{ii});
    for LL = 1:length(Boundryplot1)
        CC = plotCC(ii);
        CurrID = find(data.DepthAll{ii}>Boundryplot1(LL) & data.DepthAll{ii}<Boundryplot2(LL));
        plot(data.CutoffSFUse{ii}(CurrID),data.DepthAll{ii}(CurrID),'o','color',PlotColorSS{ii}(LL,:),...
            'markersize',Marks,'markerfacecolor',PlotColorSS{ii}(LL,:));
        axis ij;hold on;set(gca,'TickDir','Out');box off;plot([5 5],[0 1],'k--');
        WT_plotboundry([PlotR(1),PlotR(2)],'k',12);xlim([PlotR(1),PlotR(2)]);
        set(gca, 'YTick', [0 1],'fontsize',8);set(gca,'linewidth',1.5);
        axis([PlotR(1),PlotR(2) 0 1]);set(gca,'xscale','log');
        box off;ylabel('Relative depth');
    end
    CurrIDAll = find(data.DepthAll{ii}>0 & data.DepthAll{ii}<=1);
    text(0.6*max(PlotR),-0.05,['N = ',num2str(length(CurrIDAll))],'fontsize',10);
    xlabel('Cutoff SF (cycles/degree)');
end

clear meanPlot stdPlot nnnscutSFuse stdPlot;
for ii = 1:length(plotCC)
    CC = plotCC(ii);
    for LLs = 1:length(Boundryplot11)
        CurrID1 = find(data.DepthAll{ii}>Boundryplot11(LLs) & data.DepthAll{ii}<Boundryplot12(LLs));
        [nnnscutSFuse(ii,LLs,:),bbbs] = hist(log10(data.CutoffSFUse{ii}(CurrID1)),linspace((0),(1.1),12));
        meanPlot(LLs,ii) = 10^mean(log10(data.CutoffSFUse{ii}(CurrID1)));
        stdPlot(LLs,ii) = 10^(std(log10(data.CutoffSFUse{ii}(CurrID1)))/sqrt(length(CurrID1)));
    end
end

PlotColorSS{1} = [0.5 0.5 0.5;0.5 0.5 0.5;0  0.8  1;1.0000 0.55  0.55;0  0.8 0 ;0  0.8 0];
PlotColorSS{2} = [0 0 0; 0 0 0; 0 0 1;1 0 0;0 0.4 0; 0 0.4 0;];

setin = 75;plotLL = [6:-1:1];
for LL = 1:length(Boundryplot11)
    subplot(5,5,[1,6,11]+4);currM = [];
    for ii = 1:length(plotCC)
        currp = squeeze(nnnscutSFuse(ii,plotLL(LL),:));
        semilogx(10.^bbbs,100*currp/sum(currp)+(LL-1)*setin,'color',PlotColorSS{ii}(plotLL(LL),:),'linewidth',2);hold on;
        set(gca,'TickDir','Out');box off;
        currM = [currM,max(currp/sum(currp))];
        plot(squeeze(meanPlot(plotLL(LL),ii)),49+(LL-1)*setin,'v','color',PlotColorSS{ii}(plotLL(LL),:),...
            'linewidth',2,'markerfacecolor',PlotColorSS{ii}(plotLL(LL),:));
    end
    text(10,49+(LL-1)*setin,Lalernamess{plotLL(LL)});
end
axis([1.6 16 0 430]);


subplot(3,4,[10]);LL2 = 4;LL1 = 1;
for CC = 1:2
    curr1 = data.meanCutoffSFforL23{CC};
    curr2 = data.meanCutoffSFforL4Cb{CC};
    loglog(curr2,curr1,'.','color',PlotColor(CC,:));
    hold on;loglog([1 20],[1 20],'k');axis square;box off;set(gca,'TickDir','Out');
    xlabel(['Cutoff SF  L4Cb']);ylabel(['Cutoff SF  L2/3']);axis([1.8 20 1.8 20]);
end

subplot(5,5,[24]);
for CC = 1:2
    curr22 = data.meanCutoffSFforL23{CC};
    curr11 = data.meanCutoffSFforL4Cb{CC};
    curr1 = log10(curr11)-log10(curr22);
    [aaa,bbb] = hist(curr1,[-0.5:0.1:0.5]);
    plot(bbb,(aaa),'color',PlotColor(CC,:),'linewidth',2);hold on;
end
box off;set(gca,'TickDir','Out');
xlabel('difference');
ylabel('Number');





%% statistic
%%%%%% between two columns
clear hhhCutoffSF pppCutoffSF;
for LL = 1:length(Boundryplot11)
    CurrID1 = find(data.DepthAll{1}>Boundryplot11(LL)  & data.DepthAll{1}<Boundryplot12(LL));
    CurrID2 = find(data.DepthAll{2}>Boundryplot11(LL)  & data.DepthAll{2}<Boundryplot12(LL));
    [pppCutoffSF(LL),hhhCutoffSF(LL)]= ranksum((data.CutoffSFUse{1}(CurrID1)),(data.CutoffSFUse{2}(CurrID2)));
end

%%%%% from 4Cb to 2/3
CC =1;%%%%%% group 1
curr2 = data.meanCutoffSFforL4Cb{CC};
curr1 = data.meanCutoffSFforL23{CC};
[pppComp1,hhhComp1] = signrank(curr2,curr1);

CC =2;%%%%%% group 2
curr1 = data.meanCutoffSFforL4Cb{CC};
curr2 = data.meanCutoffSFforL23{CC};
[pppCompL2,hhhComp2] = signrank(curr2,curr1);






