%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData5.mat'];
load(Datapathway);

%% correlation between output/input activation and  cutoff SF
PlotColor = [0.5 0.5 0.5;0 0 0];SFlabel = {'Low SF','High SF'};
figure(5);
for SS1 = 1:2
    subplot(2,1,SS1);
    curr1 = [];curr2 = [];
    for CC = 1:2
        semilogx(data.PlotUnitOIact{SS1,CC},data.PlotUnitCutoff{SS1,CC},'o',...
            'color',PlotColor(CC,:),'markerfacecolor',PlotColor(CC,:),'markersize',1.5);hold on;
        curr1 = [curr1,log10(data.PlotUnitOIact{SS1,CC})];
        curr2 = [curr2,data.PlotUnitCutoff{SS1,CC}];
    end
    [chhsss,cppsss] = corrcoef(curr1,curr2);
    Useppp(SS1) = cppsss(1,2);Usehhh(SS1) = chhsss(1,2);Usennn(SS1) = length(curr1);
    set(gca,'TickDir','Out');box off;
    axis square;ylabel(['cutoff L2/3',' vs  L4Cb']);
    xlabel(['OIindex L2/3',' vs  L4Cb']);
    axis([0.01 100 -0.8 0.8]);
    text(0.02,0.85,['r = ',num2str(round(chhsss(1,2)*100)/100)]);
    text(10,0.85,['p = ',num2str(round(cppsss(1,2)*10000)/10000)]);
    text(10,-0.6,['n = ',num2str(length(curr1))]);text(15,0,SFlabel{SS1});
end


