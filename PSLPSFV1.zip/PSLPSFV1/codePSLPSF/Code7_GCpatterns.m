%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData7.mat'];
load(Datapathway);

%% GC pattern
LabelName = {'2','3','4B','4Ca','4Cb','5','6'};
LabelPosAlly = [0.1,0.2,0.415,0.49,0.615,0.74,0.92];
LabelPosAllx = [0.1,0.2,0.405,0.49,0.615,0.74,0.92];

figure(7);set(7,'position',[100 100 1000 600]);
%%%%%%% averaged from all SFs
for ii1 = 1:2
    currR = squeeze((data.GCAllsf(:,:,ii1)));
    subplot(2,4,1+(ii1-1)*4);
    currR1 = currR;currR1 = currR1/max(currR1(:));
    imagesc(data.RelDepthNew,data.RelDepthNew,currR1,[0 1]);hold on;
    axis square;WT_plotboundry([0 1],'w',16);WT_plotboundry([0 1],'w',17);
    colormap jet;
    for ll = 1:length(LabelPosAlly)
        text(1.1,LabelPosAlly(ll),LabelName{ll},'fontsize',8);
    end
    for ll = 1:length(LabelPosAllx)
        text(LabelPosAllx(ll),1.2,LabelName{ll},'fontsize',8,'Rotation',90);
    end
    set(gca,'TickDir','Out');set(gca,'XTick',[]);set(gca,'YTick',[]);
    text(-0.22,0.5,'To');text(0.3,1.3,'From');title('All SFs');
    text(-0.6,0.2,['Group ',num2str(ii1)],'fontsize',15);
end

%%%%%% three SFs level
LeverName = {'Low SF','Moderate SF','High SF'};
for ii1 = 1:2
    currR = squeeze((data.GC3sf(:,:,:,ii1)));
    for SS = 1:3
        subplot(2,4,(ii1-1)*4+SS+1);
        currR1 = squeeze((currR(:,:,SS)));currR1 = currR1/max(currR(:));
        imagesc(data.RelDepthNew,data.RelDepthNew,currR1,[0 0.8]);hold on;
        axis square;WT_plotboundry([0 1],'w',16);WT_plotboundry([0 1],'w',17);
        
    for ll = 1:length(LabelPosAlly)
        text(1.1,LabelPosAlly(ll),LabelName{ll},'fontsize',8);
    end
    for ll = 1:length(LabelPosAllx)
        text(LabelPosAllx(ll),1.2,LabelName{ll},'fontsize',8,'Rotation',90);
    end
        set(gca,'TickDir','Out');set(gca,'XTick',[]);set(gca,'YTick',[]);
        text(0.5,1.3,'From');box off;title(LeverName{SS});
    end
end
