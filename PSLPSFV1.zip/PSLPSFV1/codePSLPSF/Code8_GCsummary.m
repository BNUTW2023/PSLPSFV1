%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData8.mat'];
load(Datapathway);

%% get average relative GC 
clear ConnectSFRel stdConnectSFRel;
for ii1 = 1:2
    for SS=1:3
        currRawdata =  data.RelGCall{ii1,SS};
        ConnectSFRel(SS,ii1) = mean(currRawdata);
        stdConnectSFRel(SS,ii1) = std(currRawdata)/sqrt(length(currRawdata));
    end
end

%%
figure(8);set(8,'position',[100 100 1000 600]);
subplot(1,2,1);
plotXall = [1.5,3.5,7,9];
nn = 0;RandScale = 0.15;PlotColor = [0.5 0.5 0.5;0 0 0];currM = 0.001;
for ii = 1:2
    for CC = 1:2
        nn = nn + 1;
        currmeanAll =  data.GCallSFsession{CC,ii};currmeanAll(currmeanAll>currM) = currM;
        currmean = squeeze(mean(currmeanAll));
        currstd = squeeze(std(currmeanAll))/sqrt(length(currmeanAll));
        bar([plotXall(nn)],currmean,1,'Edgecolor',PlotColor(CC,:),'Facecolor',[1 1 1],'linewidth',1);hold on;
        xxxp1 = RandScale*randn([1 length(currmeanAll)]);
        plot(xxxp1+plotXall(nn),currmeanAll,'.','color',PlotColor(CC,:));hold on;
        errorbar([plotXall(nn)],currmean,currstd,'.','color',[1 0. 0.],'linewidth',1);
    end
end
box off; set(gca,'TickDir','Out');axis([0 10.5 0 0.0012]);set(gca,'xtick',plotXall);axis square;
set(gca,'xticklabel',{'Group1','Group2','Group1','Group2'});ylabel('GC value','fontsize',12);
text(1.5,-0.0002,'Recurrent');text(7,-0.0002,'Feedforward');

%%%%%% three SFs level
subplot(1,2,2);
errorbar(1:3,ConnectSFRel(:,1),stdConnectSFRel(:,1),'color',[0.5 0.5 0.5],'linewidth',2);hold on;
errorbar(1:3,ConnectSFRel(:,2),stdConnectSFRel(:,2),'k','linewidth',2);hold on;
axis square;box off;
set(gca,'xtick',[1:3]);set(gca,'xticklabel',{'Low','Medium','High'},'fontsize',12);
ylabel('Normalized GC value','fontsize',12);
title('Recurrent connection','fontsize',12);
axis([0.5 3.5 0.05 0.2]);

%% statistic
%%%%%%% ii = 1 for recurrent; ii=2 for feedforward
for ii = 1:2
    [pppRawGC(ii),hhhRawGC(ii)] = ranksum(squeeze(data.GCallSFsession{1,ii})...
        ,squeeze(data.GCallSFsession{2,ii}));
end

%%%%%%% relative GC change with SF, anova test
CC = 2; %%%%%%% for column type 2
strengthss = [];Lengthsss = [];
for SS = 1:3
    currRawdata = squeeze(data.RelGCall{CC,SS})';
    strengthss = [strengthss,currRawdata];
    Lengthsss = [Lengthsss,length(data.RelGCall{CC,SS})];
end

sumLengthsss = cumsum(Lengthsss);
Lengthsss1 = [1,sumLengthsss(1:end-1)+1];
Lengthsss2 = [sumLengthsss];
clear FitLabelAll;
for ii = 1:length(strengthss)
    FitLabelAll{ii} = [];
end
FitLabel = {'L','M','H'};
for ii = 1:length(FitLabel)
    currRange = [Lengthsss1(ii):Lengthsss2(ii)];
     for kk = 1:length(currRange)
         FitLabelAll{currRange(kk)} = FitLabel{ii};
     end
end

samples = [ones(size(strengthss,1),1),ones(size(strengthss,1),1)+1,ones(size(strengthss,1),1)+2];
strengthssUse = [strengthss(:),samples(:)];
welchanova(strengthssUse,0.05);



%%%%%%% relative GC change with SF, anova test
CC = 1; %%%%%%% for column type 1
strengthss = [];Lengthsss = [];
for SS = 1:3
    currRawdata = squeeze(data.RelGCall{CC,SS})';
    strengthss = [strengthss,currRawdata];
    Lengthsss = [Lengthsss,length(data.RelGCall{CC,SS})];
end

sumLengthsss = cumsum(Lengthsss);
Lengthsss1 = [1,sumLengthsss(1:end-1)+1];
Lengthsss2 = [sumLengthsss];
clear FitLabelAll;
for ii = 1:length(strengthss)
    FitLabelAll{ii} = [];
end
FitLabel = {'L','M','H'};
for ii = 1:length(FitLabel)
    currRange = [Lengthsss1(ii):Lengthsss2(ii)];
     for kk = 1:length(currRange)
         FitLabelAll{currRange(kk)} = FitLabel{ii};
     end
end

samples = [ones(size(strengthss,1),1),ones(size(strengthss,1),1)+1,ones(size(strengthss,1),1)+2];
strengthssUse = [strengthss(:),samples(:)];
welchanova(strengthssUse,0.05);

