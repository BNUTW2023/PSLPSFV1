%% load data
clear all;
Datapathway = ['D:\Codes\PSLPSFV1\dataPSLPSF\PSLPSFData9.mat'];
load(Datapathway);

%% show Model performance
TT = -50:2:250;
figure(10);set(10,'position',[50 150 700 400]);
subplot(2,4,1);currM = data.ExpDataDemo;
currMax = max(currM(:));
imagesc(TT,data.depth,data.ExpDataDemo/currMax,[-0.3 1]);hold on;
set(gca,'TickDir','Out');box off;axis([0 150 0 1]);WT_plotboundry([0 150],'k',16);
set(gca,'xtick',[0:50:150]);box off;set(gca,'TickDir','Out');set(gca,'ytick',[0 1]);title('Experimental data');
xlabel('Time (ms)');ylabel('Relative Depth');colormap jet;

subplot(2,4,2);tt = 0:2:150;
imagesc(tt,data.depth,data.FFRecfit/currMax,[-0.3 1]);hold on;
set(gca,'TickDir','Out');box off;axis([0 150 0 1]);WT_plotboundry([0 150],'k',16);
set(gca,'xtick',[0:50:150]);box off;set(gca,'TickDir','Out');set(gca,'ytick',[0 1]);title('FF&Rec model');
xlabel('Time (ms)');ylabel('Relative Depth');colormap jet;
subplot(2,4,3);
imagesc(tt,data.depth,data.FFfit/currMax,[-0.3 1]);hold on;
set(gca,'TickDir','Out');box off;axis([0 150 0 1]);WT_plotboundry([0 150],'k',16);
set(gca,'xtick',[0:50:150]);box off;set(gca,'TickDir','Out');set(gca,'ytick',[0 1]);title('FF model');
xlabel('Time (ms)');ylabel('Relative Depth');colormap jet;

aa = subplot(2,4,4);
plot(data.gofFF,data.gofFFRec,'ko','color',[0.3 0.3 0.3],'markersize',1.5,'markerfacecolor',[0.3 0.3 0.3]);
hold on;axis([0.4 1 0.4 1]);plot([0 1],[0 1],'k--');
axis square;box off;box off;set(gca,'TickDir','Out');
Getpos = get(aa,'position');set(gca,'xtick',[0.4:0.2:1]);set(gca,'ytick',[0.4:0.2:1]);
text(0.8,0.6,['n = ',num2str(length(data.gofFF))]);
xlabel('Gof - FF');ylabel('Gof - FF&Rec');


%% show three components
RelDepth = 0:0.01:1;
figure(11);set(11,'position',[50 150 650 280]);
currDyn = data.MpathwayFF;
currDynN = currDyn/max(currDyn(:));
subplot(1,3,1);
imagesc(tt,RelDepth,currDynN,[-0.3 1]);hold on;xlim([0 150]);box off;set(gca,'TickDir','Out');
WT_plotboundry([0 150],'k',16);set(gca, 'YTick', [0 1]);set(gca, 'YTick', [0 1]);
hold on;xlim([0 150]);box off;set(gca,'TickDir','Out');
xlabel('Time (ms)');ylabel('Relative Depth');title('M pathway Feedforward');colormap jet;

currDyn = data.PpathwayFF;
currDynN = currDyn/max(currDyn(:));
subplot(1,3,2);
imagesc(tt,RelDepth,currDynN,[-0.3 1]);hold on;xlim([0 150]);box off;set(gca,'TickDir','Out');
WT_plotboundry([0 150],'k',16);set(gca, 'YTick', [0 1]);set(gca, 'YTick', [0 1]);
hold on;xlim([0 150]);box off;set(gca,'TickDir','Out');
xlabel('Time (ms)');ylabel('Relative Depth');title('P pathway Feedforward');colormap jet;

currDyn  = data.Rec;
currDynN = currDyn/max(currDyn(:));
subplot(1,3,3);
imagesc(tt,RelDepth,currDynN,[-0.3 1]);hold on;xlim([0 150]);box off;set(gca,'TickDir','Out');
WT_plotboundry([0 150],'k',16);set(gca, 'YTick', [0 1]);
hold on;xlim([0 150]);box off;set(gca,'TickDir','Out');
xlabel('Time (ms)');ylabel('Relative Depth');title('Recurrent');
posbar = colorbar;set(posbar,'position',[0.95,0.35,0.008,0.2]);colormap jet;







