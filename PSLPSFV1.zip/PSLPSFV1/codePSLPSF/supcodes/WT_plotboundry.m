function WT_plotboundry(x_lim,color,flag)
%%%%%%% plot layer boundry
MarSize = 1;
boundry = [0.442,0.50,0.61,0.6945,0.779,0.89];
% boundry = [44.2,50,61,69.45,77.9,89];
% boundry = [44.2,50,61,69.45,76.65,89];
switch(flag),
    case 1 %%%%% 4C sub layer,5,6 compound
        switch(color),
            case({'k'})
                plot(x_lim,[boundry(1) boundry(1)],'--k');
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'--k');
                plot(x_lim,[boundry(3) boundry(3)],'--k');
                plot(x_lim,[boundry(4) boundry(4)],'--k');
                plot(x_lim,[boundry(5) boundry(5)],'--k');
            case({'w'})
                plot(x_lim,[boundry(1) boundry(1)],'--w');
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'--w');
                plot(x_lim,[boundry(3) boundry(3)],'--w');
                plot(x_lim,[boundry(4) boundry(4)],'--w');
                plot(x_lim,[boundry(5) boundry(5)],'--w');
        end
        
    case 2 %%%%% 5,6 independent
        switch(color),
            case({'k'})
                plot(x_lim,[boundry(1) boundry(1)],'--k');
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'--k');
                plot(x_lim,[boundry(3) boundry(3)],'--k');
                plot(x_lim,[boundry(5) boundry(5)],'--k');
                plot(x_lim,[boundry(6) boundry(6)],'--k');
            case({'w'})
                plot(x_lim,[boundry(1) boundry(1)],'--w','MarkerSize',1);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'--w','MarkerSize',1);
                plot(x_lim,[boundry(3) boundry(3)],'--w','MarkerSize',1);
                plot(x_lim,[boundry(5) boundry(5)],'--w','MarkerSize',1);
                plot(x_lim,[boundry(6) boundry(6)],'--w','MarkerSize',1);
        end
        
       case 3 %%%%% Rhesus 5,6 independent
%         boundry = [38,41.33,48,61,74,87];
        boundry = [0.38,0.4133,0.48,0.58,0.68,0.84];
%         boundry = [35,37.9,43.9,57.95,72,86];
        switch(color),
            case({'k'})
                plot(x_lim,[boundry(1) boundry(1)],'--k','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'--k','Linewidth',MarSize);
            case({'w'})
                plot(x_lim,[boundry(1) boundry(1)],'--w','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'--w','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'--w','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'--w','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'--w','Linewidth',MarSize);
        end 
       case 4 %%%%% Rhesus 5,6 independent
%         boundry = [38,41.33,48,61,74,87];
%         boundry = [38,41.33,48,58,68,84];
%         boundry = [0.35,0.379,0.439,0.5795,0.72,0.86];

        boundry = [0.35,0.37,0.43,0.55,0.67,0.81];
        switch(color),
            case({'k'})
                plot(x_lim,[boundry(1) boundry(1)],'--k','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'--k','Linewidth',MarSize);
            case({'w'})
                plot(x_lim,[boundry(1) boundry(1)],'w--','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'w--','Linewidth',MarSize);
%                 plot(x_lim,[boundry(1) boundry(1)],'--w','Linewidth',MarSize);
%                 hold on;
%                 plot(x_lim,[boundry(2) boundry(2)],'--w','Linewidth',MarSize);
%                 plot(x_lim,[boundry(3) boundry(3)],'--w','Linewidth',MarSize);
%                 plot(x_lim,[boundry(5) boundry(5)],'--w','Linewidth',MarSize);
%                 plot(x_lim,[boundry(6) boundry(6)],'--w','Linewidth',MarSize);
        end 
        
        case 5 %%%%% Rhesus 5,6 independent
%         boundry = [0.35,0.379,0.439,0.5795,0.72,0.86];
        boundry = [0.35,0.37,0.43,0.55,0.67,0.81];
        switch(color),
            case({'k'})
                plot(x_lim,[boundry(1) boundry(1)],'k--','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'k--','Linewidth',MarSize);
            case({'w'})
                plot(x_lim,[boundry(1) boundry(1)],'w--','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'w--','Linewidth',MarSize);
        end 
        case 6 %%%%% Rhesus 5,6 independent
%         boundry = [0.35,0.379,0.439,0.5795,0.72,0.86];
        boundry = [0.35,0.37,0.43,0.55,0.67,0.81];
        switch(color),
            case({'k'})
                plot([boundry(1) boundry(1)],x_lim,'k--','Linewidth',MarSize);
                hold on;
                plot([boundry(2) boundry(2)],x_lim,'k--','Linewidth',MarSize);
                plot([boundry(3) boundry(3)],x_lim,'k--','Linewidth',MarSize);
                plot([boundry(4) boundry(4)],x_lim,'k--','Linewidth',MarSize);
                plot([boundry(5) boundry(5)],x_lim,'k--','Linewidth',MarSize);
                plot([boundry(6) boundry(6)],x_lim,'k--','Linewidth',MarSize);
            case({'w'})
                plot([boundry(1) boundry(1)],x_lim,'w--','Linewidth',MarSize);
                hold on;
                plot([boundry(2) boundry(2)],x_lim,'w--','Linewidth',MarSize);
                plot([boundry(3) boundry(3)],x_lim,'w--','Linewidth',MarSize);
                plot([boundry(4) boundry(4)],x_lim,'w--','Linewidth',MarSize);
                plot([boundry(5) boundry(5)],x_lim,'w--','Linewidth',MarSize);
                plot([boundry(6) boundry(6)],x_lim,'w--','Linewidth',MarSize);
        end 
        
        case 7 %%%%% Rhesus 5,6 independent
%         boundry = [0.35,0.379,0.439,0.5795,0.72,0.86];
        boundry = fliplr(1-[0.35,0.37,0.43,0.55,0.67,0.81]);
        switch(color),
            case({'k'})
                plot([boundry(1) boundry(1)],x_lim,'k','Linewidth',MarSize);
                hold on;
                plot([boundry(2) boundry(2)],x_lim,'k','Linewidth',MarSize);
                plot([boundry(3) boundry(3)],x_lim,'k','Linewidth',MarSize);
                plot([boundry(4) boundry(4)],x_lim,'k','Linewidth',MarSize);
                plot([boundry(5) boundry(5)],x_lim,'k','Linewidth',MarSize);
                plot([boundry(6) boundry(6)],x_lim,'k','Linewidth',MarSize);
            case({'w'})
                plot([boundry(1) boundry(1)],x_lim,'w','Linewidth',MarSize);
                hold on;
                plot([boundry(2) boundry(2)],x_lim,'w','Linewidth',MarSize);
                plot([boundry(3) boundry(3)],x_lim,'w','Linewidth',MarSize);
                plot([boundry(4) boundry(4)],x_lim,'w','Linewidth',MarSize);
                plot([boundry(5) boundry(5)],x_lim,'w','Linewidth',MarSize);
                plot([boundry(6) boundry(6)],x_lim,'w','Linewidth',MarSize);
        end 
        case 8 %%%%% Rhesus 5,6 independent
%         boundry = [0.35,0.379,0.439,0.5795,0.72,0.86];
         boundry = [0,0.35,0.37,0.43,0.55,0.67,0.81,1];
        switch(color),
            case({'k'})
                plot(x_lim,[boundry(1) boundry(1)],'--k','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(7) boundry(7)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(8) boundry(8)],'--k','Linewidth',MarSize);
            case({'w'})
                plot(x_lim,[boundry(1) boundry(1)],'w--','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(7) boundry(7)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(8) boundry(8)],'--k','Linewidth',MarSize);
        end 
        case 9 %%%%% Rhesus 5,6 independent
%         boundry = [0.35,0.379,0.439,0.5795,0.72,0.86];
         boundry = [0.4,0.66,0.82];
        switch(color),
            case({'k'})
                plot(x_lim,[boundry(1) boundry(1)],'--k','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'--k','Linewidth',MarSize);

            case({'w'})
                plot(x_lim,[boundry(1) boundry(1)],'w--','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'w--','Linewidth',MarSize);
        end 
        
         case 10
        boundry = [0.4,0.66,0.82];
        switch(color),
            case({'k'})
                plot([boundry(1) boundry(1)],x_lim,'--k','Linewidth',MarSize);
                hold on;
                plot([boundry(2) boundry(2)],x_lim,'--k','Linewidth',MarSize);
                plot([boundry(3) boundry(3)],x_lim,'--k','Linewidth',MarSize);

            case({'w'})
                plot([boundry(1) boundry(1)],x_lim,'w--','Linewidth',MarSize);
                hold on;
                plot([boundry(2) boundry(2)],x_lim,'w--','Linewidth',MarSize);
                plot([boundry(3) boundry(3)],x_lim,'w--','Linewidth',MarSize);
        end 
        
       case 11 %%%%% Rhesus 5,6 independent
%         boundry = [38,41.33,48,61,74,87];
%         boundry = [38,41.33,48,58,68,84];
%         boundry = [0.35,0.379,0.439,0.5795,0.72,0.86];

        boundry = [0,0.35,0.37,0.43,0.55,0.67,0.81,1];
        switch(color),
            case({'k'})
                plot(x_lim,[boundry(1) boundry(1)],'--k','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'--k','Linewidth',MarSize);
                plot(x_lim,[boundry(7) boundry(7)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(8) boundry(8)],'k--','Linewidth',MarSize);
                
            case({'w'})
                plot(x_lim,[boundry(1) boundry(1)],'w--','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(7) boundry(7)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(8) boundry(8)],'w--','Linewidth',MarSize);
%                 plot(x_lim,[boundry(1) boundry(1)],'--w','Linewidth',MarSize);
%                 hold on;
%                 plot(x_lim,[boundry(2) boundry(2)],'--w','Linewidth',MarSize);
%                 plot(x_lim,[boundry(3) boundry(3)],'--w','Linewidth',MarSize);
%                 plot(x_lim,[boundry(5) boundry(5)],'--w','Linewidth',MarSize);
%                 plot(x_lim,[boundry(6) boundry(6)],'--w','Linewidth',MarSize);
        end 
        
       case 12 %%%%% Rhesus 5,6 independent
%         boundry = [0.35,0.379,0.439,0.5795,0.72,0.86];
        boundry = [0.175,0.35,0.37,0.43,0.55,0.67,0.81];
        switch(color),
            case({'k'})
                plot(x_lim,[boundry(1) boundry(1)],'k--','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'k--','Linewidth',MarSize);
                 plot(x_lim,[boundry(7) boundry(7)],'k--','Linewidth',MarSize);
            case({'w'})
                plot(x_lim,[boundry(1) boundry(1)],'w--','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(7) boundry(7)],'w--','Linewidth',MarSize);
        end 
        
                
        case 13 %%%%% Rhesus 5,6 independent
%         boundry = [0.35,0.379,0.439,0.5795,0.72,0.86];
        boundry = [0.175,0.35,0.37,0.43,0.55,0.67,0.81];
        switch(color),
            case({'k'})
                plot(x_lim,[boundry(1) boundry(1)],'k','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'k','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'k','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'k','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'k','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'k','Linewidth',MarSize);
                plot(x_lim,[boundry(7) boundry(7)],'k','Linewidth',MarSize);
            case({'w'})
                plot(x_lim,[boundry(1) boundry(1)],'w','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'w','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'w','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'w','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'w','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'w','Linewidth',MarSize);
                plot(x_lim,[boundry(7) boundry(7)],'w','Linewidth',MarSize);
        end 
        case 14 %%%%% Rhesus 5,6 independent
%         boundry = [0.35,0.379,0.439,0.5795,0.72,0.86];
        boundry = [0.175,0.35,0.37,0.43,0.55,0.67,0.81];
        switch(color),
            case({'k'})
                plot([boundry(1) boundry(1)],x_lim,'k','Linewidth',MarSize);
                hold on;
                plot([boundry(2) boundry(2)],x_lim,'k','Linewidth',MarSize);
                plot([boundry(3) boundry(3)],x_lim,'k','Linewidth',MarSize);
                plot([boundry(4) boundry(4)],x_lim,'k','Linewidth',MarSize);
                plot([boundry(5) boundry(5)],x_lim,'k','Linewidth',MarSize);
                plot([boundry(6) boundry(6)],x_lim,'k','Linewidth',MarSize);
                plot([boundry(7) boundry(7)],x_lim,'k','Linewidth',MarSize);
            case({'w'})
                plot([boundry(1) boundry(1)],x_lim,'w','Linewidth',MarSize);
                hold on;
                plot([boundry(2) boundry(2)],x_lim,'w','Linewidth',MarSize);
                plot([boundry(3) boundry(3)],x_lim,'w','Linewidth',MarSize);
                plot([boundry(4) boundry(4)],x_lim,'w','Linewidth',MarSize);
                plot([boundry(5) boundry(5)],x_lim,'w','Linewidth',MarSize);
                plot([boundry(6) boundry(6)],x_lim,'w','Linewidth',MarSize);
                plot([boundry(7) boundry(7)],x_lim,'w','Linewidth',MarSize);
        end 
        
        case 15 %%%%% Rhesus 5,6 independent
%         boundry = [0.35,0.379,0.439,0.5795,0.72,0.86];
        boundry = [0.175,0.35,0.43,0.55,0.67,0.81];
        switch(color),
            case({'k'})
                plot(x_lim,[boundry(1) boundry(1)],'k--','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'k--','Linewidth',MarSize);
%                  plot(x_lim,[boundry(7) boundry(7)],'k--','Linewidth',MarSize);
            case({'w'})
                plot(x_lim,[boundry(1) boundry(1)],'w--','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'w--','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'w--','Linewidth',MarSize);
%                 plot(x_lim,[boundry(7) boundry(7)],'w--','Linewidth',MarSize);
        end 
        
        
                case 16 %%%%% Rhesus 5,6 independent
%         boundry = [0.35,0.379,0.439,0.5795,0.72,0.86];
        boundry = [0.175,0.35,0.43,0.55,0.67,0.81];
        switch(color),
            case({'k'})
                plot(x_lim,[boundry(1) boundry(1)],'k--','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'k--','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'k--','Linewidth',MarSize);
            case({'w'})
                plot(x_lim,[boundry(1) boundry(1)],'w','Linewidth',MarSize);
                hold on;
                plot(x_lim,[boundry(2) boundry(2)],'w','Linewidth',MarSize);
                plot(x_lim,[boundry(3) boundry(3)],'w','Linewidth',MarSize);
                plot(x_lim,[boundry(4) boundry(4)],'w','Linewidth',MarSize);
                plot(x_lim,[boundry(5) boundry(5)],'w','Linewidth',MarSize);
                plot(x_lim,[boundry(6) boundry(6)],'w','Linewidth',MarSize);
        end 
        case 17 %%%%% Rhesus 5,6 independent
%         boundry = [0.35,0.379,0.439,0.5795,0.72,0.86];
        boundry = [0.175,0.35,0.43,0.55,0.67,0.81];
        switch(color),
            case({'k'})
                plot([boundry(1) boundry(1)],x_lim,'k--','Linewidth',MarSize);
                hold on;
                plot([boundry(2) boundry(2)],x_lim,'k--','Linewidth',MarSize);
                plot([boundry(3) boundry(3)],x_lim,'k--','Linewidth',MarSize);
                plot([boundry(4) boundry(4)],x_lim,'k--','Linewidth',MarSize);
                plot([boundry(5) boundry(5)],x_lim,'k--','Linewidth',MarSize);
                plot([boundry(6) boundry(6)],x_lim,'k--','Linewidth',MarSize);
            case({'w'})
                plot([boundry(1) boundry(1)],x_lim,'w','Linewidth',MarSize);
                hold on;
                plot([boundry(2) boundry(2)],x_lim,'w','Linewidth',MarSize);
                plot([boundry(3) boundry(3)],x_lim,'w','Linewidth',MarSize);
                plot([boundry(4) boundry(4)],x_lim,'w','Linewidth',MarSize);
                plot([boundry(5) boundry(5)],x_lim,'w','Linewidth',MarSize);
                plot([boundry(6) boundry(6)],x_lim,'w','Linewidth',MarSize);
        end 
end

