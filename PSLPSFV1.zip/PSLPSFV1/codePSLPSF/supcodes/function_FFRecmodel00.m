function [res,r1,r2,r3] = function_FFRecmodel00(tt,Inpa,Inpb,param)
%%% multiple dynamics composed of Three components
TimePeak1 = param(1);
TimeWidth1 = param(2);

TimePeakII1 = param(3);
TimeWidthII1 = param(4);

TimePeak2 = param(5);
TimeWidth2 = param(6);

TimePeakII2 = param(7);
TimeWidthII2 = param(8);
EIr1 = param(9);
EIr2 = param(10);
RespGain1 = param(11);RespGain2 = param(12);
SFn = size(Inpa,1);

TimePeak3 = param(13);
TimeWidth3 = param(14);
RespGain3 = param(15:end);
     
%% input from M and P pathway
rrE1 = logNormTime(tt, [0, TimePeak1, TimeWidth1, 1]);
rrI1 = logNormTime(tt, [0, TimePeakII1, TimeWidthII1, 1]);
rr1 = rrE1-EIr1*rrI1;
rr1 = rr1/(0.0000000001+max(abs(rr1)));
Trans4Ca = conv2(Inpa,rr1,'full');

rrE2 = logNormTime(tt, [0, TimePeak2, TimeWidth2, 1]);
rrI2 = logNormTime(tt, [0, TimePeakII2, TimeWidthII2, 1]);
rr2 = rrE2-EIr2*rrI2;rr2 = rr2/(0.0000000001+max(abs(rr2)));
Trans4Cb = conv2(Inpb,rr2,'full');

%%
Trans4Ca = Trans4Ca/(0.000000001+max(Trans4Ca(:)));
Trans4Cb = Trans4Cb/(0.000000001+max(Trans4Cb(:)));

%%
r1 = RespGain1*Trans4Ca(:,1:length(tt));
r2 = RespGain2*Trans4Cb(:,1:length(tt));

res1 = r1 + r2;

%% recurrent
TimeDelay3 = 0;
rrE3 = logNormTime(tt, [TimeDelay3, TimePeak3, TimeWidth3, 1]);
r3 = repmat(RespGain3,[1 length(tt)]).*repmat(rrE3,[SFn 1]);

%%
res = res1 + r3;


