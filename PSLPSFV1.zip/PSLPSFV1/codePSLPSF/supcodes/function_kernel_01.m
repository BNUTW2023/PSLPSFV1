function [res,r1] = function_kernel_01(tt,Inpa,Inpb,param)
%%% multiple dynamics composed of two components

TimeDelay1 = param(1);
TimePeak1 = param(2);
TimeWidth1 = param(3);

TimeDelayII1 = param(4);
TimePeakII1 = param(5);
TimeWidthII1 = param(6);

EIr1 = param(7);
RespGain1 = param(8);

%% input from L4 to other layers
rrE1 = logNormTime(tt, [TimeDelay1, TimePeak1, TimeWidth1, 1]);
rrI1 = logNormTime(tt, [TimeDelayII1, TimePeakII1, TimeWidthII1, 1]);
rr1 = rrE1-EIr1*rrI1;
rr1 = rr1/(0.0000000001+max(abs(rr1)));
Trans4Ca = conv2(Inpa,rr1,'full');

%%%%%%% recurrent
%%
Trans4Ca = Trans4Ca/(0.000000001+max(Trans4Ca(:)));

%%
r1 = RespGain1*Trans4Ca(:,1:length(tt));

res = r1;

% res = res/(max(res(:))+0.000000000001);
% res = res;

