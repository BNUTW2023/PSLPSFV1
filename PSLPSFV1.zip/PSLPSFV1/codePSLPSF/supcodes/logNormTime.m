function res = logNormTime(t, param),

T_Delay = param(1);
T_Mean = param(2);
T_Sigma = param(3);
T_K = param(4);

currT = t - T_Delay;
Ppos = find(currT>0);
Npos = find(currT<=0);
currT(Ppos) = exp(-((log(currT(Ppos))-log(T_Mean)).^2)/T_Sigma^2/2);
currT(Npos)=0;

res = T_K*currT;